Libraries needed: 
pandas, 
numpy, 
matplotlib,
statistics,
datetime,
geopy,
scipy